using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace MiscThings.Items.Equipables.Accessories.Shields
{
	[AutoloadEquip(EquipType.Shield)]
	public class ReinforcedTurtleShield : ModItem
	{

		public override void SetDefaults()
		{

			item.width = 36;
			item.height = 42;
			item.value = 123450;
			item.rare = 8;
			item.defense = 20;
			item.accessory = true;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Reinforced Turtle Shield");
			Tooltip.SetDefault("The less health, the more defense.\n" + "Defense is quadrupled when this shield is at its maximum potential.\n" + "nGrants 25% damage reduction.\n" + "Maximum life increased by 200");
		}


		public override void UpdateAccessory(Player player, bool hideVisual)

		{
			player.statLifeMax2 += 200;
			if (player.statLife < 50)
			{
				player.statDefense = (int)(player.statDefense * 4f);
			}
			if (player.statLife < 100)
			{
				player.statDefense = (int)(player.statDefense * 3f);
				player.AddBuff(BuffID.IceBarrier, 2);
			}
			if (player.statLife < 200)
			{
				player.statDefense = (int)(player.statDefense * 2f);
			}
			
			/*{
			float 3 = player.statLife;
			player.statDefense = (int)(player.statDefense * 3)
			}*/
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(null, "FrozenTurtleShield", 1);
			recipe.AddIngredient(null, "BeetleShield", 1);
			//recipe.AddIngredient(null, "HealthMultiplier", 1);
			recipe.SetResult(this);
			recipe.AddTile(TileID.Anvils);
			recipe.AddRecipe();
		}
	}
}
