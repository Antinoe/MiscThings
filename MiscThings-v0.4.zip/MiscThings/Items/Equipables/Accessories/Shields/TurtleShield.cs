using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace MiscThings.Items.Equipables.Accessories.Shields
{
	[AutoloadEquip(EquipType.Shield)]
	public class TurtleShield : ModItem
	{

		public override void SetDefaults()
		{

			item.width = 36;
			item.height = 42;
			item.value = 123450;
			item.rare = 8;
			item.defense = 4;

			item.accessory = true;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Turtle Shield");
			Tooltip.SetDefault("The less health, the more defense.\n" + "Defense is tripled when this shield is at its maximum potential.");
		}


		public override void UpdateAccessory(Player player, bool hideVisual)

		{
			if (player.statLife < 50)
			{
				player.statDefense = (int)(player.statDefense * 3f);
			}
			if (player.statLife < 100)
			{
				player.statDefense = (int)(player.statDefense * 2.5f);
			}
			if (player.statLife < 200)
			{
				player.statDefense = (int)(player.statDefense * 2f);
			}
			
			/*{
			float 3 = player.statLife;
			player.statDefense = (int)(player.statDefense * 3)
			}*/
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.ChlorophyteBar, 20);
			recipe.AddIngredient(ItemID.TurtleShell, 2);
			recipe.SetResult(this);
			recipe.AddTile(134);
			recipe.AddRecipe();
		}
	}
}
