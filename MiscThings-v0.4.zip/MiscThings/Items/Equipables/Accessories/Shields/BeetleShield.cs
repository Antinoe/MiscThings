using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace MiscThings.Items.Equipables.Accessories.Shields
{
	[AutoloadEquip(EquipType.Shield)]
	public class BeetleShield : ModItem
	{

		public override void SetDefaults()
		{

			item.width = 24;
			item.height = 24;
			item.value = 123110;
			item.rare = 8;
			item.defense = 6;
			item.accessory = true;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Beetle Shield");
			Tooltip.SetDefault("The less health, the more defense\nMaximum life increased by 100");
		}


		public override void UpdateAccessory(Player player, bool hideVisual)

		{
			player.statLifeMax2 += 100;
			if (player.statLife < 50)
			{
				player.statDefense = (int)(player.statDefense * 10f);
			}
			if (player.statLife < 100)
			{
				player.statDefense = (int)(player.statDefense * 5f);
			}
			if (player.statLife < 200)
			{
				player.statDefense = (int)(player.statDefense * 2.5f);
			}
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(null, "TurtleShield", 1);
			//recipe.AddIngredient(null, "LeechingSeed", 1);
			recipe.AddIngredient(ItemID.BeetleHusk, 10);
			recipe.SetResult(this);
            recipe.AddTile(TileID.Anvils);
			recipe.AddRecipe();
		}
	}
}
