using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace MiscThings.Items.Equipables.Accessories
{
	public class HardArmor : ModItem
	{

		public override void SetDefaults()
		{

			item.width = 34;
			item.height = 34;
			item.value = 90000;
			item.rare = 1;
			//item.defense = 9;
			item.accessory = true;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Hard Armor");
			Tooltip.SetDefault("Multiplies Defense by 50%.\n" + "Turns the user's Defense into Health.\n" + "This only takes into consideration the Defense added by Armor and Accessories.");
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(null, "HardBulwark", 1);
			recipe.AddIngredient(null, "WoodenFrame", 1);
            recipe.AddTile(TileID.Anvils);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}

		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			player.statDefense = (int)(player.statDefense * 1.50f);
			player.statLifeMax2 += player.statDefense * 5;
		}

	}
}
