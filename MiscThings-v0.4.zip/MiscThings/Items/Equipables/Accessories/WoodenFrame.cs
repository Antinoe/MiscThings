using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;

namespace MiscThings.Items.Equipables.Accessories
{
	public class WoodenFrame : ModItem
	{

		public override void SetDefaults()
		{

			item.width = 34;
			item.height = 34;
			item.value = 500;
			item.rare = 1;
			//item.defense = 4;
			item.accessory = true;
		}

		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Wooden Frame");
			Tooltip.SetDefault("Turns the user's Defense into Health.\n" + "This only takes into consideration the Defense added by Armor and Accessories.");
		}

		public override void AddRecipes()
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.AddIngredient(ItemID.Wood, 20);
            recipe.AddTile(TileID.WorkBenches);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		
		public override void UpdateAccessory(Player player, bool hideVisual)
		{
			//player.statDefense = (int)(player.statDefense * 1.25f);
			//^ Old method that didn't work.
			
			player.statLifeMax2 += player.statDefense * 5;
			//player.MiscThings().HasWoodenFrameEquipped = true;
			//HasWoodenFrameEquipped;
		}
	}
}
